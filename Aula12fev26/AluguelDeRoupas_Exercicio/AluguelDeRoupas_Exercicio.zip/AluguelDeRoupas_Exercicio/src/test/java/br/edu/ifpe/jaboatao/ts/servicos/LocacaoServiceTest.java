package br.edu.ifpe.jaboatao.ts.servicos;

import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

import br.edu.ifpe.jaboatao.ts.entidades.Cliente;
import br.edu.ifpe.jaboatao.ts.entidades.Locacao;
import br.edu.ifpe.jaboatao.ts.entidades.Roupa;

public class LocacaoServiceTest {
	@Test
	public void teste01() {

		LocacaoService service = new LocacaoService();
		
		//Cenario
		Locacao Locacaocliente1 = new Locacao();
		Cliente cliente1 = new Cliente("Marisa");
		Roupa roupa1 = new Roupa("Blusa Xadrez","G",10,20.00);
		
		//Acao
		Locacaocliente1 = service.alugarRoupa(cliente1, roupa1);
		
		//verificação
		assertTrue(Locacaocliente1.getCliente().getNome() == "Marisa");
		assertTrue(Locacaocliente1.getValorLocacao() == 20);
	}
}
